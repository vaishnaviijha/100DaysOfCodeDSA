// NAME: Vaishnavi Kumari
// SAP ID: 590029048
// DATE: 22/01/2026
                                    // LAB 1
// Q1.Tick an array of length 10 make a function call the array in the function print the value

#include <stdio.h>
void show(int *arr)
{
    int i;
    for (i = 0; i < 10; i++)
    {
        printf("%d ", *(arr + i));
    }
}
int main()
{
    int arr[10] = {1,2,3,4,5,6,7,8,9,10};
    show(arr);
    return 0;
}
