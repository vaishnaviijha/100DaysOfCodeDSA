// NAME: Vaishnavi Kumari
// SAP ID: 590029048
// DATE: 22/01/2026
                                    // LAB 1
// Q2. Write a C program to store and display details of 2 students using dynamic memory allocation.
//Each student has:
//•	Roll number
//•	Name
//•	CGPA of Sem-1

#include <stdio.h>
#include <stdlib.h>

struct StudentData
{
    int rollno;
    char name[15];
    float cgpa;
};

int main()
{
    int count = 2, i;
    struct StudentData *ptr;
    ptr = (struct StudentData *)malloc(count * sizeof(struct StudentData));

    if (ptr == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }

    
    for (i = 0; i < count; i++)
    {
        printf("\nEnter details of Student %d\n", i + 1);

        printf("Roll No.: ");
        scanf("%d", &ptr->rollno);

        printf("Name: ");
        scanf("%s", ptr->name);

        printf("CGPA of Sem1: ");
        scanf("%f", &ptr->cgpa);

        ptr++;   
    }

    ptr = ptr - count;

    printf("\nStudent Details\n");
    for (i = 0; i < count; i++)
    {
        printf("\nStudent %d\n", i + 1);
        printf("Roll No.: %d\n", ptr->rollno);
        printf("Name: %s\n", ptr->name);
        printf("CGPA of Sem1: %.2f\n", ptr->cgpa);

        ptr++;
    }
    free(ptr - count);
    return 0;
}
