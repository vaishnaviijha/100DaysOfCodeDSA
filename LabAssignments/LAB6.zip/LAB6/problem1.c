// Name: Vaishnavi Kumari
// SAP ID: 590029048

// Problem Statement 1
// Write a C program to represent two polynomials using singly linked lists and perform polynomial addition.
// Each node should store:
// •	Coefficient
// •	Exponent
// •	Pointer to next node

//REQUIRED CODE:
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int coeff;          
    int exp;            
    struct Node* next; 
} node;


node* createNode(int c, int e) {
    node* newNode = (node*)malloc(sizeof(node));
    newNode->coeff = c;
    newNode->exp = e;
    newNode->next = NULL;
    return newNode;
}


node* insert(node* head, int c, int e) {
    node* newNode = createNode(c, e);

    if (head == NULL || e > head->exp) {
        newNode->next = head;
        return newNode;
    }

    node* temp = head;
    while (temp->next != NULL && temp->next->exp > e) {
        temp = temp->next;
    }

    newNode->next = temp->next;
    temp->next = newNode;

    return head;
}


node* addPoly(node* p1, node* p2) {
    node* result = NULL;

    while (p1 != NULL && p2 != NULL) {
        if (p1->exp == p2->exp) {
            result = insert(result, p1->coeff + p2->coeff, p1->exp);
            p1 = p1->next;
            p2 = p2->next;
        }
        else if (p1->exp > p2->exp) {
            result = insert(result, p1->coeff, p1->exp);
            p1 = p1->next;
        }
        else {
            result = insert(result, p2->coeff, p2->exp);
            p2 = p2->next;
        }
    }

    
    while (p1 != NULL) {
        result = insert(result, p1->coeff, p1->exp);
        p1 = p1->next;
    }

    while (p2 != NULL) {
        result = insert(result, p2->coeff, p2->exp);
        p2 = p2->next;
    }

    return result;
}


void display(node* head) {
    while (head != NULL) {
        printf("%dx^%d", head->coeff, head->exp);
        if (head->next != NULL)
            printf(" + ");
        head = head->next;
    }
    printf("\n");
}


int main() {
    node *poly1 = NULL, *poly2 = NULL, *result = NULL;
    int n, c, e;

    
    printf("Enter number of terms in Polynomial 1: ");
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("Enter coefficient and exponent: ");
        scanf("%d %d", &c, &e);
        poly1 = insert(poly1, c, e);
    }

    
    printf("Enter number of terms in Polynomial 2: ");
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("Enter coefficient and exponent: ");
        scanf("%d %d", &c, &e);
        poly2 = insert(poly2, c, e);
    }

    
    printf("\nPolynomial 1: ");
    display(poly1);

    printf("Polynomial 2: ");
    display(poly2);


    result = addPoly(poly1, poly2);

    printf("Resultant Polynomial: ");
    display(result);

    return 0;
}

