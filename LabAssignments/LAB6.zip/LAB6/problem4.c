//Problem Statement 4
// Write a C program to compare two polynomials represented using linked lists.
// Return:
// •	1 if equal
// •	0 if not equal

//REQUIRED CODE:

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int coeff;
    int exp;
    struct Node* next;
};

struct Node* createNode(int c, int e) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->coeff = c;
    newNode->exp = e;
    newNode->next = NULL;
    return newNode;
}

void insertTerm(struct Node** head, int c, int e) {
    struct Node* newNode = createNode(c, e);
    newNode->next = *head;
    *head = newNode;
}

int compare(struct Node* p1, struct Node* p2) {
    while (p1 != NULL && p2 != NULL) {
        if (p1->coeff != p2->coeff || p1->exp != p2->exp)
            return 0;
        p1 = p1->next;
        p2 = p2->next;
    }

    if (p1 == NULL && p2 == NULL)
        return 1;

    return 0;
}

void display(struct Node* head) {
    while (head != NULL) {
        printf("%dx^%d", head->coeff, head->exp);
        if (head->next != NULL)
            printf(" + ");
        head = head->next;
    }
    printf("\n");
}

int main() {
    struct Node* poly1 = NULL;
    struct Node* poly2 = NULL;

    insertTerm(&poly1, 1, 0);
    insertTerm(&poly1, 3, 1);
    insertTerm(&poly1, 2, 2);

    insertTerm(&poly2, 1, 0);
    insertTerm(&poly2, 3, 1);
    insertTerm(&poly2, 2, 2);

    printf("Polynomial 1: ");
    display(poly1);

    printf("Polynomial 2: ");
    display(poly2);

    if (compare(poly1, poly2))
        printf("Result: 1 (Polynomials are equal)\n");
    else
        printf("Result: 0 (Polynomials are not equal)\n");

    return 0;
}