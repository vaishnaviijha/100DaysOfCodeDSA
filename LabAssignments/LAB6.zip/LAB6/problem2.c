// Name: Vaishnavi Kumari
// SAP ID: 590029048

//Problem Statement 2
// Write a C program to multiply two polynomials using linked lists.
// Requirements
// •	Multiply each term of first polynomial with second
// •	Combine like terms
// •	Display final polynomial

//REQUIRED CODE:

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int coeff;
    int exp;
    struct Node* next;
};

struct Node* createNode(int c, int e) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->coeff = c;
    newNode->exp = e;
    newNode->next = NULL;
    return newNode;
}

void insertTerm(struct Node** head, int c, int e) {
    struct Node *temp = *head, *prev = NULL;

    while (temp != NULL && temp->exp > e) {
        prev = temp;
        temp = temp->next;
    }

    if (temp != NULL && temp->exp == e) {
        temp->coeff += c;
        return;
    }

    struct Node* newNode = createNode(c, e);

    if (prev == NULL) {
        newNode->next = *head;
        *head = newNode;
    } else {
        newNode->next = temp;
        prev->next = newNode;
    }
}

struct Node* multiply(struct Node* poly1, struct Node* poly2) {
    struct Node* result = NULL;

    for (struct Node* p1 = poly1; p1 != NULL; p1 = p1->next) {
        for (struct Node* p2 = poly2; p2 != NULL; p2 = p2->next) {
            int coeff = p1->coeff * p2->coeff;
            int exp = p1->exp + p2->exp;
            insertTerm(&result, coeff, exp);
        }
    }

    return result;
}

void display(struct Node* head) {
    while (head != NULL) {
        printf("%dx^%d", head->coeff, head->exp);
        if (head->next != NULL)
            printf(" + ");
        head = head->next;
    }
    printf("\n");
}

int main() {
    struct Node* poly1 = NULL;
    struct Node* poly2 = NULL;
    struct Node* result = NULL;

    insertTerm(&poly1, 2, 2);
    insertTerm(&poly1, 3, 1);
    insertTerm(&poly1, 1, 0);

    insertTerm(&poly2, 1, 1);
    insertTerm(&poly2, 4, 0);

    result = multiply(poly1, poly2);

    printf("Result: ");
    display(result);

    return 0;
}

